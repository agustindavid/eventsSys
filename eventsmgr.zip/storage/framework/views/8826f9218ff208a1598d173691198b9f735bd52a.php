<?php $__env->startSection('pageTitle', 'Eventos'); ?>

<?php $__env->startSection('content'); ?>
<div class="row dataInfo">
<div class="col-md-4">
  <h2>Detalles del evento</h2>
  <div class="row">
    <div class="col">
      <p>Cliente:<strong> <?php echo e($event->quote->client->name); ?> <?php echo e($event->quote->client->lastname); ?></strong></p>
    </div>
  </div>
  <div class="row">
    <div class="col">
      <p>Nombre del evento: <strong><?php echo e($event->quote->eventName); ?></strong></p>
    </div>
  </div>
  <div class="row">
    <div class="col">
      <p>Salón: <strong><?php echo e($event->quote->venue->name); ?></strong></p>
    </div>
  </div>
  <div class="row">
    <div class="col">
      <p>Fecha de inicio: <strong><?php echo \Carbon\Carbon::parse($event->quote->eventDate)->format('d-m-Y'); ?></strong></p>
    </div>
  </div>
  <div class="row">
    <div class="col">
      <p>Hora de inicio: <strong><?php echo e($event->quote->eventTime); ?></strong></p>
    </div>
  </div>
  <div class="row">
    <div class="col">
      <p>Fecha final: <strong><?php echo \Carbon\Carbon::parse($event->quote->eventFinishDate)->format('d-m-Y'); ?></strong></p>
   </div>
  </div>
  <div class="row">
   <div class="col">
     <p>Hora final: <strong><?php echo e($event->quote->eventFinishTime); ?></strong></p>
   </div>
  </div>
  <div class="row">
    <div class="col">
      <p>Nombre del paquete seleccionado: <strong><?php echo e($event->quote->package->name); ?></strong></p>
    </div>
  </div>
  <div class="row">
    <div class="col">
      <p>Servicios incluidos</p>
      <ul>
      <?php $__currentLoopData = $event->quote->package->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <li><?php echo e($service->name); ?></li>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </div>
  <div class="row">
      <div class="col">
        <p>Extras:</p>
        <p><?php echo e($event->quote->extras); ?></p>
      </div>
  </div>
</div>
<div class="col-md-8">
  <div class="row">
    <div class="col">
      <h2>Resumen de cuenta:</h2>
      <p>Costo total del evento: <?php echo e($event->quote->price); ?>$</p>
      <p>Monto pagado hasta la fecha: <?php echo e($event->total_paid); ?>$</p>
      <p>Monto por pagar hasta la fecha: <?php echo e($event->quote->price-$event->total_paid); ?>$</p>
    </div>
</div>
        <div class="hiddenFormWrapper defaultForm">
        <h3 class="panel-title">Nuevo abono para el Evento <?php echo e($event->quote->eventName); ?></h3>
                <form role="form" class="newPaymentForm">
                <?php echo e(csrf_field()); ?>

                <input type="hidden" name="user_id" value="1">
                <input type="hidden" name="event_id" value="<?php echo e($event->id); ?>">
                <input type="hidden" name="debtAmount" value="<?php echo e($event->quote->price); ?>">
                <input type="hidden" name="payTotal" value="0">
                <input type="hidden" name="id" id="paymentId">
                  <div class="form-row form-group">
                    <div class="col">
                      <label for="amount">Cantidad a abonar</label>
                      <input type="number" step="0.01" max="<?php echo e($event->quote->price-$event->total_paid); ?>" min="1" name="amount" id="amount" class="form-control input-sm" placeholder="">
                    </div>
                    <div class="col">
                      <label for="payMethod">Forma de pago:</label>
                      <input type="text" name="payMethod" id="payMethod" class="form-control input-sm" placeholder="Forma de pago">
                    </div>
                  </div>
                  <div class="form-row form-group">
                    <div class="col">
                      <label for="payDate">Fecha de pago</label>
                      <input type="text" name="payDate" id="payDate" class="form-control input-sm" placeholder="Dia de pago">
                    </div>
                  </div>
                  <div class="form-row form-group">
                    <div class="col">
                      <label for="comments">Comentarios</label>
                      <textarea name="comments" id="comments" class="form-control input-sm"></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                      <input type="submit"  value="Guardar" class="btn btn-success btn-block createClient">
                      <a href="#" class="btn btn-info btn-block hiddenFormClose" >Cerrar</a>
                  </div>
                </form>
              </div>
              <div class="alert alert-success success-message" role="alert"></div>
        <h3  style="margin-top:30px;">Pagos Realizados</h3>
        <table class="table">
            <tr>
                <th>Monto pagado</th>
                <th>Fecha de pago</th>
                <th>Forma de pago</th>
                <th>Monto adeudado</th>
                <th>Total pagado</th>
                <th>Comentario</th>
            </tr>
            <?php $__currentLoopData = $event->payments->sortBy('payDate'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($payment->status==1): ?>
                <tr>
                  <td>
                    <?php echo e($payment->amount); ?>

                  </td>
                  <td>
                    <?php echo \Carbon\Carbon::parse($payment->payDate)->format('d-m-Y'); ?>

                  </td>
                  <td>
                    <?php echo e($payment->payMethod); ?>

                  </td>
                  <td>
                    <?php echo e($payment->debtAmount); ?>

                  </td>
                  <td>
                    <?php echo e($payment->payTotal); ?>

                  </td>
                  <td>
                    <?php echo e($payment->comments); ?>

                  </td>
                </tr>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <h3  style="margin-top:30px;">Pagos por realizar</h3>
        <table class="table">
          <tr>
            <th>Monto a pagar</th>
            <th>Fecha de vencimiento</th>
            <th>Acciones</th>
          </tr>
          <?php $__currentLoopData = $event->payments->sortBy('tentativeDate'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($payment->status==0): ?>
              <tr>
                <td>
                  <p><?php echo e($payment->toBePaid); ?></p>
                </td>
                <td>
                  <?php if(\Carbon\Carbon::parse($payment->tentativeDate) < \Carbon\Carbon::now()): ?>
                    <span style="color:red"><?php echo \Carbon\Carbon::parse($payment->tentativeDate)->format('d-m-Y'); ?></span>
                  <?php else: ?>
                  <?php echo \Carbon\Carbon::parse($payment->tentativeDate)->format('d-m-Y'); ?>

                  <?php endif; ?>
                </td>
                <td>
                  <?php if($payment->toBePaid < 1): ?>
                    <button class="makePay btn btn-primary" data-amount="<?php echo e($payment->toBePaid); ?>" disabled data-payment="<?php echo e($payment->id); ?>">Realizar pago</button>
                  <?php else: ?>
                    <button class="makePay btn btn-primary" data-amount="<?php echo e($payment->toBePaid); ?>" data-payment="<?php echo e($payment->id); ?>">Realizar pago</button>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <h4><button class="btn btn-primary makePay" href="#" class="showHiddenForm">Registrar nuevo pago para este evento</button></h4>
      </div>
    </div>
</div>
</div>





<script>
$(document).ready(function(){
  $('.showHiddenForm, .hiddenFormClose').click(function(e){
    e.preventDefault();
    $('.hiddenFormWrapper').slideToggle();
  });
  $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
});

$('#payDate').datepicker({
        format:'yyyy/mm/dd',
        language: 'es',
        endDate: 'today',
        todayHighlight: true
    });

$('.newPaymentForm').submit(function(event) {
event.preventDefault();
var paymentID=$('input[name=id]').val();
if(paymentID != ''){
    requestType='PUT';
    requestUrl='/api/payment/'+paymentID;
} else {
    requestUrl='/api/payment';
    requestType='POST';
}
var formData = {
    'id': $('input[name=id]').val(),
    'amount': $('input[name=amount]').val(),
    'payMethod': $('input[name=payMethod]').val(),
    'payDate': $('input[name=payDate]').val(),
    'tentativeDate': $('input[name=tentativeDate]').val(),
    'debtAmount': $('input[name=debtAmount]').val(),
    'payTotal': $('input[name=payTotal]').val(),
    'comments': $('textarea[name=comments]').val(),
    'user_id': $('input[name=user_id]').val(),
    'event_id': $('input[name=event_id]').val()
};
// process the form
$.ajax({
    type        : requestType, // define the type of HTTP verb we want to use (POST for our form)
    url         : requestUrl, // the url where we want to POST
    data        : formData // our data object
}).done(function(data) {
        $('.newPaymentForm').trigger("reset");
        $('.createClient').attr('disabled', 'disabled');
        $('.hiddenFormWrapper').slideToggle();
        $('.success-message').slideToggle();
        $('.success-message').html(data.msg);
        console.log(data);

        // here we will handle errors and validation messages
    });
});

$('.makePay').click(function(event) {
  event.preventDefault();
  $('.hiddenFormWrapper').slideToggle();
  $('#paymentId').val($(this).data('payment'));
  $('#amount').val($(this).data('amount'));
});
});

</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/events/show.blade.php ENDPATH**/ ?>