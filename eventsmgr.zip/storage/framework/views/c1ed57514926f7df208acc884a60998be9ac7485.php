<?php echo e($venue); ?>

<?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/venues/show.blade.php ENDPATH**/ ?>