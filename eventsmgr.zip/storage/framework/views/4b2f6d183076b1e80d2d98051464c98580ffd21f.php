<?php $__env->startSection('pageTitle', 'services'); ?>

<?php $__env->startSection('content'); ?>

            <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if(Session::has('success')): ?>
            <div class="alert alert-info">
                <?php echo e(Session::get('success')); ?>

            </div>
            <?php endif; ?>


                    <h3 class="panel-title">Nueva Ubicacion</h3>

                        <form method="POST" action="<?php echo e(route('venues.store')); ?>"  role="form">
                            <?php echo e(csrf_field()); ?>

                                  <input type="text" name="name" id="name" class="form-control input-sm" placeholder="Nombre">
                                        <input type="text" name="location" id="pac-input" class="controls form-control input-sm" placeholder="Ubicacion">
                                        <input type="number" name="mincapacity" id="maxcapacity" class="form-control input-sm" placeholder="Capacidad Minima">
                                        <input type="number" name="maxcapacity" id="maxcapacity" class="form-control input-sm" placeholder="Capacidad Maxima">
                                    <input type="submit"  value="Guardar" class="btn btn-success btn-block">
                                    <a href="<?php echo e(route('venues.index')); ?>" class="btn btn-info btn-block" >Atrás</a>
                        </form>

                        <script>
                            var defaultBounds = new google.maps.LatLngBounds(
  new google.maps.LatLng(21.955454, -101.200713),
  new google.maps.LatLng(22.335762, -100.792730));

var input = document.getElementById('pac-input');
var options = {
  //types: ['establishment']
};

autocomplete = new google.maps.places.Autocomplete(input, options);
                        </script>
        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/venues/create.blade.php ENDPATH**/ ?>