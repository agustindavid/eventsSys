<?php $__env->startSection('pageTitle', 'services'); ?>

<?php $__env->startSection('content'); ?>




<script>

  document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
      plugins: [ 'interaction', 'dayGrid', 'timeGrid' ],
      defaultView: 'dayGridMonth',
      defaultDate: '2019-08-07',
      color: 'yellow',   // a non-ajax option
      textColor: 'black', // a non-ajax option
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,timeGridWeek,timeGridDay'
      },
      events: 'http://localhost:8000/api/calendar'
    });

    calendar.render();
  });

</script>

</head>
<body>

  <div id='calendar'></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/calendar.blade.php ENDPATH**/ ?>