<?php $__env->startSection('pageTitle', 'packagees'); ?>

<?php $__env->startSection('content'); ?>
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <strong>Error!</strong> Revise los campos obligatorios.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                <div class="alert alert-info">
                    <?php echo e(Session::get('success')); ?>

                </div>
                <?php endif; ?>


                        <h3 class="panel-title">Nuevo servicio</h3>
                            <form method="POST" action="<?php echo e(route('services.store')); ?>"  role="form">
                                <?php echo e(csrf_field()); ?>

                                            <input type="text" name="name" id="name" class="form-control input-sm" placeholder="Nombre">
                                            <input type="text" name="servicePrice" id="servicePrice" class="form-control input-sm" placeholder="Precio">
                                            <select name="category_id" id="category_id">
                                            <?php $__currentLoopData = $services_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($service_category->id); ?>"><?php echo e($service_category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <input type="submit"  value="Guardar" class="btn btn-success btn-block">
                                        <a href="<?php echo e(route('services.index')); ?>" class="btn btn-info btn-block" >Atrás</a>
                            </form>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/services/create.blade.php ENDPATH**/ ?>