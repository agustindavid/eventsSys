<?php $__env->startSection('pageTitle', 'packagees'); ?>

<?php $__env->startSection('content'); ?>


<h2><?php echo e($package->name); ?></h2>

<h3>Servicios</h3>

<?php $__currentLoopData = $allServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u_service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($u_service->packages->contains($package->id)): ?>
    <input type="checkbox" name="vehicle" checked="checked" value="Bike"><?php echo e($u_service->name); ?><br>
  <?php else: ?>
  <input type="checkbox" name="vehicle" value="Bike"><?php echo e($u_service->name); ?><br>
  <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/packages/show.blade.php ENDPATH**/ ?>