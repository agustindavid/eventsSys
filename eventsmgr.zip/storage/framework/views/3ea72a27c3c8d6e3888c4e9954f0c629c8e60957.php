<?php $__env->startSection('pageTitle', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>
			<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<strong>Error!</strong> Revise los campos obligatorios.<br><br>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<?php if(Session::has('success')): ?>
			<div class="alert alert-info">
				<?php echo e(Session::get('success')); ?>

			</div>
			<?php endif; ?>

	            <h3 class="panel-title">Editar Paquete</h3>
						<form method="POST" action="<?php echo e(route('packages.update',$package->id)); ?>"  role="form">
							<?php echo e(csrf_field()); ?>

							<input name="_method" type="hidden" value="PATCH">
										<input type="text" name="name" id="name" class="form-control input-sm" value="<?php echo e($package->name); ?>">
										<input type="text" name="price" id="price" class="form-control input-sm" value="<?php echo e($package->price); ?>">
	                                    <?php $__currentLoopData = $allServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u_service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($u_service->packages->contains($package->id)): ?>
                                              <input type="checkbox" name="services[]" checked="checked" value="<?php echo e($u_service->id); ?>"><?php echo e($u_service->name); ?><br>
                                            <?php else: ?>
                                            <input type="checkbox" name="services[]" value="<?php echo e($u_service->id); ?>"><?php echo e($u_service->name); ?><br>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    								<input type="submit"  value="Actualizar" class="btn btn-success btn-block">
									<a href="<?php echo e(route('packages.index')); ?>" class="btn btn-info btn-block" >Atrás</a>
						</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/packages/edit.blade.php ENDPATH**/ ?>