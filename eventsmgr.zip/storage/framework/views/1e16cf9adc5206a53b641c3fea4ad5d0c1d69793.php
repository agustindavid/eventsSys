<?php $__env->startSection('pageTitle', 'services'); ?>

<?php $__env->startSection('content'); ?>

<div class="defaultForm">
  <?php if(count($errors) > 0): ?>
    <div class="alert alert-danger">
      <strong>Error!</strong> Revise los campos obligatorios.<br><br>
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    </div>
  <?php endif; ?>
  <?php if(Session::has('success')): ?>
    <div class="alert alert-info">
      <?php echo e(Session::get('success')); ?>

    </div>
   <?php endif; ?>
   <h3 class="panel-title">Nueva Ubicacion</h3>
   <form method="POST" class="newVenueForm"  role="form">
   <?php echo e(csrf_field()); ?>

   <div class="form-row form-group">
     <div class="col">
       <label for="name">Nombre</label>
       <input type="text" name="name" id="name" class="form-control input-sm" placeholder="Nombre">
     </div>
     <div class="col">
       <label for="location">Ubicacion</label>
       <input type="text" name="location" id="pac-input" class="controls form-control input-sm" placeholder="Ubicacion">
     </div>
   </div>
   <div class="form-row form-group">
     <div class="col">
       <label for="mincapacity">Minimo de personas recomendado</label>
       <input type="number" name="mincapacity" id="maxcapacity" class="form-control input-sm" placeholder="Capacidad Minima">
      </div>
      <div class="col">
        <label for="maxcapacity">Capacidad maxima</label>
        <input type="number" name="maxcapacity" id="maxcapacity" class="form-control input-sm" placeholder="Capacidad Maxima">
      </div>
    </div>
    <div class="form-group">
      <input type="submit"  value="Guardar" class="btn btn-success btn-block createClient">
      <a href="#" class="btn btn-info btn-block clientFormClose" >Cerrar</a>
    </div>
  </form>
</div>
<div class="alert alert-success success-message" role="alert"></div>

<table class="stripe infotable" id="venuesTable">
  <thead>
      <tr>
          <th>Nombre</th>
          <th>Direccion</th>
          <th>Minimo de personas recomendado</th>
          <th>Capacidad Maxima</th>
      </tr>
  </thead>
  <tbody>
      <?php $__currentLoopData = $venues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $venue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td><?php echo e($venue->name); ?></td>
          <td><?php echo e($venue->location); ?></td>
          <td><?php echo e($venue->mincapacity); ?></td>
          <td><?php echo e($venue->maxcapacity); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<script>
  $(document).ready( function () {
    var table=$('#venuesTable').DataTable();

  $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
});

$('.newVenueForm').submit(function(event) {
event.preventDefault();
var formData = {
    'name': $('input[name=name]').val(),
    'location': $('input[name=location]').val(),
    'mincapacity': $('input[name=mincapacity]').val(),
    'maxcapacity': $('input[name=maxcapacity]').val(),
    };
// process the form
$.ajax({
    type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
    url         : '/api/venues', // the url where we want to POST
    data        : formData // our data object
}).done(function(data) {
        $('.newVenueForm').trigger("reset");
        $('.success-message').slideToggle();
        $('.success-message').html(data.msg);
        console.log(data);
        window.location.reload();
        // here we will handle errors and validation messages
    });
});
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/venues/index.blade.php ENDPATH**/ ?>