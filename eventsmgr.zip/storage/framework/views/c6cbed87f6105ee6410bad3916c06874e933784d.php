<nav id="sidebar-nav">
    <ul class="nav sidebar-list">
        <li><a href="/clients"><i class="fas fa-chalkboard-teacher"></i>Clientes</a></li>
        <li><a href="/venues"><i class="fas fa-hotel"></i>Locaciones</a></li>
        <li><a href="/categories"><i class="fas fa-list-ul"></i>Categorias</a></li>
        <li><a href="/services"><i class="fas fa-concierge-bell"></i>Servicios</a></li>
        <li><a href="/packages"><i class="fas fa-cubes"></i>Paquetes</a></li>
        <li><a href="/quotes"><i class="fas fa-file-invoice"></i>Cotizaciones</a></li>
        <li><a href="/events"><i class="fas fa-birthday-cake"></i>Eventos</a></li>
        <li><a href="/calendar"><i class="fas fa-calendar"></i>Calendario</a></li>
        <li><a href="/payments"><i class="fas fa-calendar"></i>Pagos</a></li>
        <li><a href="/calendar"><i class="fas fa-calendar"></i>Gastos</a></li>
    </ul>
</nav>
<?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>