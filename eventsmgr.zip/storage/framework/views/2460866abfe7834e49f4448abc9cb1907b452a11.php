Footer
<?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/includes/footer.blade.php ENDPATH**/ ?>