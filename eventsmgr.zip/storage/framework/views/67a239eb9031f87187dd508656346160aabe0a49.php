<?php $__env->startSection('pageTitle', 'quotees'); ?>

<?php $__env->startSection('content'); ?>

<?php echo e($payments); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/payments/index.blade.php ENDPATH**/ ?>