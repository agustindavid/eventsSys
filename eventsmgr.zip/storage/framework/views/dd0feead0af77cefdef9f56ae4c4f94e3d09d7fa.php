<?php $__env->startSection('pageTitle', 'quotees'); ?>

<?php $__env->startSection('content'); ?>

<p>Cliente: <?php echo e($quote->client->name); ?> <?php echo e($quote->client->lastname); ?></p>
<p>Nombre del evento: <?php echo e($quote->eventName); ?></p>
<p>Fecha del evento: <?php echo e($quote->eventDate); ?></p>
<p>Hora del evento:<?php echo e($quote->eventTime); ?></p>
<p>Fecha final:<?php echo e($quote->eventFinishDate); ?></p>
<p>Hora Final<?php echo e($quote->eventFinishTime); ?></p>
<p>Precio: <?php echo e($quote->price); ?></p>
<p>Estado: <?php echo e($quote->status); ?></p>
<p>Cantidad de personas: <?php echo e($quote->peopleQty); ?></p>
<p>Valido hasta: <?php echo e($quote->validThru); ?></p>
<p>Locacion: <?php echo e($quote->venue->name); ?></p>
<p>Paquete: <?php echo e($quote->package->name); ?></p>
<p>Servicios:</p>
<ul>
<?php $__currentLoopData = $quote->package->services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><?php echo e($service->name); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/quotes/show.blade.php ENDPATH**/ ?>