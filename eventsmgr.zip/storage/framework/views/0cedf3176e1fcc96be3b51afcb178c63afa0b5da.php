<?php $__env->startSection('pageTitle', 'quotees'); ?>

<?php $__env->startSection('content'); ?>
<a href="/quotes/create">Nueva Cotizacion</a>
<table id="quotesTable" class="infotable">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Fecha Prevista</th>
            <th>Cliente</th>
            <th>Paquete</th>
            <th>Locacion</th>
            <th>Precio</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $quotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
           <td><a href="/quotes/<?php echo e($quote->id); ?>"><?php echo e($quote->eventName); ?></a></td>
           <td><?php echo e($quote->eventDate); ?></td>
           <td><?php echo e($quote->client->name); ?> <?php echo e($quote->client->lastname); ?></td>
           <td><?php echo e($quote->package->name); ?></td>
           <td><?php echo e($quote->venue->name); ?></td>
           <td><?php echo e($quote->price); ?></td>
         <td><a href="/quotes/<?php echo e($quote->id); ?>/edit">Editar</a> - Eliminar</td>
         </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <script>
    $(document).ready( function () {
      $('#quotesTable').DataTable();
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/quotes/index.blade.php ENDPATH**/ ?>