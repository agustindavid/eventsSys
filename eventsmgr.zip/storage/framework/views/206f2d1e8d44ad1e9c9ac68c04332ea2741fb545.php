<?php $__env->startSection('pageTitle', 'packagees'); ?>

<?php $__env->startSection('content'); ?>
			<?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<strong>Error!</strong> Revise los campos obligatorios.<br><br>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<?php if(Session::has('success')): ?>
			<div class="alert alert-info">
				<?php echo e(Session::get('success')); ?>

			</div>
			<?php endif; ?>

                <h3 class="panel-title">Editar Servicio</h3>
						<form method="POST" action="<?php echo e(route('services.update',$service->id)); ?>"  role="form">
							<?php echo e(csrf_field()); ?>

							<input name="_method" type="hidden" value="PATCH">
										<input type="text" name="name" id="name" class="form-control input-sm" value="<?php echo e($service->name); ?>">
                                        <input type="text" name="servicePrice" id="servicePrice" class="form-control input-sm" value="<?php echo e($service->servicePrice); ?>">
                                        <select name="category_id" id="category_id">
                                            <?php $__currentLoopData = $services_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($service_category->id); ?>" <?php echo e(($service_category->id == $service->category_id) ? 'selected' : ''); ?>><?php echo e($service_category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
									<input type="submit"  value="Actualizar" class="btn btn-success btn-block">
									<a href="<?php echo e(route('services.index')); ?>" class="btn btn-info btn-block" >Atrás</a>
						</form>

	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/services/edit.blade.php ENDPATH**/ ?>