<?php $__env->startSection('pageTitle', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>

        <?php if(count($errors) > 0): ?>
			<div class="alert alert-danger">
				<strong>Error!</strong> Revise los campos obligatorios.<br><br>
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
			<?php if(Session::has('success')): ?>
			<div class="alert alert-info">
				<?php echo e(Session::get('success')); ?>

			</div>
			<?php endif; ?>

                <h3 class="panel-title">Editar Cliente</h3>
						<form method="POST" action="<?php echo e(route('clients.update',$client->id)); ?>"  role="form">
							<?php echo e(csrf_field()); ?>

							<input name="_method" type="hidden" value="PATCH">

										<input type="text" name="name" id="name" class="form-control input-sm" value="<?php echo e($client->name); ?>">
						            <input type="text" name="lastname" id="lastname" class="form-control input-sm" value="<?php echo e($client->lastname); ?>">
										<input type="text" name="email" id="email" class="form-control input-sm" value="<?php echo e($client->email); ?>">
						                <input type="text" name="rfc" id="rfc" class="form-control input-sm" value="<?php echo e($client->rfc); ?>">
                        				<input type="text" name="fiscalname" id="fiscalname" class="form-control input-sm" value="<?php echo e($client->fiscalname); ?>">
						                <input type="text" name="commercialname" id="commercialname" class="form-control input-sm" value="<?php echo e($client->commercialname); ?>">
                                        <input type="text" name="phone" id="phone" class="form-control input-sm" value="<?php echo e($client->phone); ?>">
                        			<input type="submit"  value="Actualizar" class="btn btn-success btn-block">
									<a href="<?php echo e(route('clients.index')); ?>" class="btn btn-info btn-block" >Atrás</a>
						</form>
                        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/clients/edit.blade.php ENDPATH**/ ?>