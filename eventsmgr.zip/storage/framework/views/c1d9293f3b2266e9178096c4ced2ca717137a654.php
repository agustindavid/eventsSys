<?php $__env->startSection('pageTitle', 'packagees'); ?>

<?php $__env->startSection('content'); ?>
<div class="defaultForm">
<h3 class="panel-title">Nuevo Paquete</h3>
  <form method="POST" class="newPackageForm"  role="form">
  <?php echo e(csrf_field()); ?>

    <div class="form-row form-group">
      <div class="col">
        <label for="name">Nombre del paquete</label>
        <input type="text" name="name" id="name" class="form-control input-sm" placeholder="Nombre">
      </div>
      <div class="col">
        <label for="minQty">Cantidad minima de personas</label>
        <input type="number" name="minQty" id="minQty" class="form-control input-sm" placeholder="Cantidad minima de personas">
      </div>
    </div>
    <div class="form-group form-row">
      <div class="col">
        <label for="kidsPrice">Precio por niño</label>
        <input type="number" name="kidsPrice" id="kidsPrice" class="form-control input-sm" placeholder="Precio por niño">
      </div>
      <div class="col">
        <label for="adultPrice">Precio por adulto</label>
        <input type="number" name="adultPrice" id="adultPrice" class="form-control input-sm" placeholder="Precio por adulto">
      </div>
  </div>
  <div class="servicesSelection form-group">
    <?php $__currentLoopData = $allServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-check">
      <input type="checkbox" class="form-check-input" id="service<?php echo e($service->id); ?>" name="services[]" value="<?php echo e($service->id); ?>">
      <label class="form-check-label" for="service<?php echo e($service->id); ?>"><?php echo e($service->name); ?></label>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="form-group form-row">
    <input type="submit"  value="Guardar" class="btn btn-success btn-block createClient">
    <a href="#" class="btn btn-info btn-block clientFormClose" >Cerrar</a>
  </div>
 </form>
</div>
<table id="packagesTable" class="infotable">
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Precio por niño</th>
            <th>Precio por adulto</th>
            <th>Cantidad mínima de personas</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
           <td><a href="/packages/<?php echo e($package->id); ?>"><?php echo e($package->name); ?></a></td>
           <td><?php echo e($package->kidsPrice); ?></td>
           <td><?php echo e($package->adultPrice); ?></td>
           <td><?php echo e($package->minQty); ?></td>
         <td><a href="/packages/<?php echo e($package->id); ?>/edit">Editar</a> - Eliminar</td>
         </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<script>
  $(document).ready( function () {
    $('#packagesTable').DataTable();

    $.ajaxSetup({
  headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
  }
});

$('.newServiceForm').submit(function(event) {
event.preventDefault();
var formData = {
    'name': $('input[name=name]').val(),
    'kidsPrice': $('input[name=kidsPrice]').val(),
    'adultPrice': $('input[name=adultPrice]').val(),
    'minQty': $('input[name=minQty]').val(),
    'services': $('input[name=services[]]').val(),
    };
// process the form
$.ajax({
    type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
    url         : '/api/packages', // the url where we want to POST
    data        : formData // our data object
}).done(function(data) {
        $('.newServiceForm').trigger("reset");
        $('.success-message').slideToggle();
        $('.success-message').html(data.msg);
        console.log(data);
        window.location.reload();
        // here we will handle errors and validation messages
    });
});

  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/packages/index.blade.php ENDPATH**/ ?>