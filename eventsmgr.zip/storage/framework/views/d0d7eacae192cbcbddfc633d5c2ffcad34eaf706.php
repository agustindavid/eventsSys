<?php $__env->startSection('pageTitle', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>
<?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <strong>Error!</strong> Revise los campos obligatorios.<br><br>
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>
<?php if(Session::has('success')): ?>
  <div class="alert alert-info">
    <?php echo e(Session::get('success')); ?>

  </div>
<?php endif; ?>
<div class="defaultForm">
  <h3 class="panel-title">Nuevo Paquete</h3>
    <form method="POST" action="<?php echo e(route('packages.store')); ?>"  role="form">
    <?php echo e(csrf_field()); ?>

    <div class="form-row form-group">
      <div class="col">
        <label for="name">Nombre del paquete</label>
        <input type="text" name="name" id="name" class="form-control input-sm" placeholder="Nombre">
      </div>
      <div class="col">
            <label for="minQty">Cantidad minima de personas</label>
            <input type="number" name="minQty" id="minQty" class="form-control input-sm" placeholder="Cantidad minima de personas">
      </div>
    </div>
    <div class="form-group form-row">
      <div class="col">
        <label for="kidsPrice">Precio por niño</label>
        <input type="number" name="kidsPrice" id="kidsPrice" class="form-control input-sm" placeholder="Precio por niño">
      </div>
      <div class="col">
        <label for="adultPrice">Precio por adulto</label>
        <input type="number" name="adultPrice" id="adultPrice" class="form-control input-sm" placeholder="Precio por adulto">
      </div>

    </div>
    <div class="servicesSelection form-group">
      <?php $__currentLoopData = $allServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="form-check">
        <input type="checkbox" class="form-check-input" id="service<?php echo e($service->id); ?>" name="services[]" value="<?php echo e($service->id); ?>">
        <label class="form-check-label" for="service<?php echo e($service->id); ?>"><?php echo e($service->name); ?></label>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="form-group form-row">
      <input type="submit"  value="Guardar" class="btn btn-success btn-block">
      <a href="<?php echo e(route('packages.index')); ?>" class="btn btn-info btn-block" >Atrás</a>
    </div>
                        </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/packages/create.blade.php ENDPATH**/ ?>