<?php $__env->startSection('pageTitle', 'packages'); ?>

<?php $__env->startSection('content'); ?>

<?php echo e($service->name); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/services/show.blade.php ENDPATH**/ ?>