<?php $__env->startSection('pageTitle', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>
<p>Nombre: <?php echo e($client->name); ?> <?php echo e($client->lastname); ?></p>
<p>Email: <?php echo e($client->email); ?></p>
<p>RFC: <?php echo e($client->rfc); ?></p>
<p>Nombre fiscal: <?php echo e($client->fiscalname); ?></p>
<p>Nombre comercial: <?php echo e($client->commercialname); ?></p>
<p>Telefono: <?php echo e($client->phone); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/clients/show.blade.php ENDPATH**/ ?>