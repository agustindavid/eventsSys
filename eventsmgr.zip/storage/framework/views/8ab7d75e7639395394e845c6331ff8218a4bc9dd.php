<!doctype html>
<html>
<head>
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div class="container-fluid">

    <header class="row">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </header>

    <div id="main" class="row">

        <!-- sidebar content -->
        <div id="sidebar" class="sidebar">
            <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <!-- main content -->
        <div id="content-page" class="content-page">
            <div class="page-wrap">
              <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>

    </div>

    <footer class="row">
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>

</div>
</body>
</html>
<?php /**PATH D:\xampp\htdocs\eventosSys\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>