@extends('layouts.sidebar')

@section('pageTitle', 'quotees')

@section('content')

{{$payments}}

@endsection
