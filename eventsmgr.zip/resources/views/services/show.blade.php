@extends('layouts.sidebar')

@section('pageTitle', 'packages')

@section('content')

{{ $service->name }}

@endsection
