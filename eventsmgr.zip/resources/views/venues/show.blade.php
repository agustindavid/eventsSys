@extends('layouts.sidebar')

@section('pageTitle', 'services')

@section('content')


{{$venue}}

@endsection
