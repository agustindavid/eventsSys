@extends('layouts.layout')

@section('title')
    Home
@endsection

@section('content')
   <p>This is the content.</p>
@endsection
